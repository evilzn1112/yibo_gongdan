/**
 * Created by lzw on 14-8-16.
 */
var should = require('should');
var express = require('express')
  , Route = express.Route
  , assert = require('assert');
var request = require('supertest');
var winston = require('winston');

describe('Ticket',function(){

});